package main;

import planner.etapa1.view.TelaUsuario;
import java.util.Scanner;


public class PlannerEtapa1 {

  
    public static void main(String[] args) {
        TelaUsuario tu = new TelaUsuario();
        tu.setVisible(true);
    }   
    }
       

